package com.example.vinicius.projeto_3msin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.app.ListActivity;

import android.os.Bundle;

import android.view.View;

import android.widget.ArrayAdapter;

import android.widget.ListView;

import android.widget.Toast;

    public class ListarCurso extends ListActivity {



        private String[] lstEstados;



        public void onCreate(Bundle icicle) {

            super.onCreate(icicle);

            //Criar um array de Strings, que será utilizado em seu ListActivity

            lstEstados = new String[] {"São Paulo", "Rio de Janeiro", "Minas Gerais", "Rio Grande do Sul",

                    "Santa Catarina", "Paraná", "Mato Grosso", "Amazonas"};



            //Criar um ArrayAdapter, que vai fazer aparecer as Strings acima

            //em seu ListView

            this.setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lstEstados));

        }



        @Override

        protected void onListItemClick(ListView l, View v, int position, long id) {

            super.onListItemClick(l, v, position, id);



            //Pegar o item clicado

            Object o = this.getListAdapter().getItem(position);

            String lstrEstado = o.toString();



            //Apresentar o item clicado

            Toast.makeText(this, "Você clicou no estado : " + lstrEstado, Toast.LENGTH_LONG).show();

        }

    }


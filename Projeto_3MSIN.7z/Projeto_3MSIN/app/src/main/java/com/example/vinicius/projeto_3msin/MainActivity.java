package com.example.vinicius.projeto_3msin;


import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        private String mActivityName;
        private TextView mStatusView;
        private TextView mStatusAllView;


        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            mActivityName = getString(R.string.activity_a);
            mStatusView = (TextView)findViewById(R.id.status_view_a);

        }


        public void startNext(View v) {
            Intent intent = new Intent(MainActivity.this, ListarCurso.class);
            startActivity(intent);
        }


    }



